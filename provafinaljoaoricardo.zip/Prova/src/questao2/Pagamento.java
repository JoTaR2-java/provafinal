package questao2;
//criacao de uma interface que cria escopo de metodos que devem ser implementados na classe que for solicitado
public interface Pagamento {
public void preco();
public void pagar(Aluno a);
}
