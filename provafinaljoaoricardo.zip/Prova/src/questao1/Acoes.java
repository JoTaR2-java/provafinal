package questao1;

/*aqui � criada uma  interface que na verdade funciona como contrato de metodos
 * ou seja ela criar os nomes dos metodos que no decorrer do codigo , na classe em que for o utilizado
 * .... implemets Acoes , seja implementado de fato o funcionamento do metodo , abrindo espa�o para utilzi��o de polimorfismo
 * do tive override e overload , mudando as assinaturas dos metodos em suas classes de implementa��o
*/
public interface Acoes {
	public void receber();
	public void pagar();
	

}
